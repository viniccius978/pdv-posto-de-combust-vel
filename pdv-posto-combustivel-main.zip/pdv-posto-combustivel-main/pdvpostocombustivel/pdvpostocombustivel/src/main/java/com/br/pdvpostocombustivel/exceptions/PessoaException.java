package com.br.pdvpostocombustivel.exceptions;

public class PessoaException extends RuntimeException {
    public PessoaException(String message) {
        super(message);
    }
}
