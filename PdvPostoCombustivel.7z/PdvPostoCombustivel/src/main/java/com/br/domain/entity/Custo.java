package com.br.domain.entity;

import java.util.Date;

public class Custo {

    private Double imposto;
    private Double custoVariavel;
    private Double custoFixo;
    private Double MargemLucro;
    private Date dataProcessamento;

    public Custo(double imposto, double custoVariavel, double custoFixo, Date dataProcessamento) {}

}