package com.br.domain.entity;
import java.math.BigDecimal;

public class Estoque {

    private BigDecimal quantidade;
    private String LocalTanque;
    private String LocalEndereco;
    private String LoteFabricacao;
    private String dataValidade;

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

    public String getLocalTanque() {
        return LocalTanque;
    }

    public void setLocalTanque(String LocalTanque) {
        this.LocalTanque = LocalTanque;
    }

    public String getLocalEndereco() {
        return LocalEndereco;
    }

    public void setLocalEndereco(String LocalEndereco) {
        this.LocalEndereco = LocalEndereco;
    }

    public String getLoteFabricacao() {
        return LoteFabricacao;
    }

    public void setLoteFabricacao(String LoteFabricacao) {
        this.LoteFabricacao = LoteFabricacao;
    }

    public String getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }

    public BigDecimal getQuantidadeTotal() {
        return quantidade;
    }
    public void setQuantidadeTotal(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }
}